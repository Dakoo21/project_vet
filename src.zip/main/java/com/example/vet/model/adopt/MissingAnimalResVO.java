package com.example.vet.model.adopt;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MissingAnimalResVO {

    //요청번호
    private String reqNo;

    private String resultCode;


}
