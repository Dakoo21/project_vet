package com.example.vet.repository.myPage;

public class Info_Repository {
}
