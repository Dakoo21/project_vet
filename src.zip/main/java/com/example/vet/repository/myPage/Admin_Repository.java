package com.example.vet.repository.myPage;

public class Admin_Repository {
}
