package com.example.vet.repository.board;

public class Abandon_Pet_Repository {
}
