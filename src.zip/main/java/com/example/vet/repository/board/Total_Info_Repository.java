package com.example.vet.repository.board;

public class Total_Info_Repository {
}
