package com.example.vet.repository.board;

public class Notice_Board_Repository {
}
