package com.example.vet.repository.work;

public class Draft_Repository {
}
