package com.example.vet.repository.work;

public class Stock_Repository {
}
