package com.example.vet.controller.board;

public class Notice_Board_Controller {
}
