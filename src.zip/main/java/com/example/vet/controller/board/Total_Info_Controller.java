package com.example.vet.controller.board;

public class Total_Info_Controller {
}
