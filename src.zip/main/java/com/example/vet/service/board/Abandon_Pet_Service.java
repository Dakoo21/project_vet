package com.example.vet.service.board;

public class Abandon_Pet_Service {
}
