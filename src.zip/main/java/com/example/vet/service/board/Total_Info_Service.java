package com.example.vet.service.board;

public class Total_Info_Service {
}
