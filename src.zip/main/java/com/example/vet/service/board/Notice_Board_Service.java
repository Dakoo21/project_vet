package com.example.vet.service.board;

public class Notice_Board_Service {
}
