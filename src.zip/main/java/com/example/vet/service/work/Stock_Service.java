package com.example.vet.service.work;

import com.example.vet.model.StockCommonVO;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class Stock_Service {
//    public List<Map<String, Object>> Select(StockCommonVO stockCommonVO) {
//    }
//

}
