package com.example.vet.service.myPage;

public class Info_Service {
}
