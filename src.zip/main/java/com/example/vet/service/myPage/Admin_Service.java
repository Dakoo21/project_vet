package com.example.vet.service.myPage;

public class Admin_Service {
}
