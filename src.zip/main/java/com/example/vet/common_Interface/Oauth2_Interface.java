package com.example.vet.common_Interface;

public interface Oauth2_Interface {

    String USER_USERNAME(); //유저이름
    String USER_EMAIL();
    String USER_PROVIDER();
    String USER_PROVIDERID();
}
